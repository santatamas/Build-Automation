// Copyright (c) Microsoft Corporation. All rights reserved. See License.txt in the project root for license information.

using System.Windows.Controls;

namespace BasicMVVMQuickstart_Desktop.Views
{
    /// <summary>
    /// Interaction logic for QuestionnaireView.xaml
    /// </summary>
    public partial class QuestionnaireView : UserControl
    {
        public QuestionnaireView()
        {
            InitializeComponent();
        }
    }
}
